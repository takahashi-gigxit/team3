<template>
  <div class="profile-done">
    <h2>プロフィール更新完了</h2>
    <p>プロフィールの変更が保存されました。</p>
  </div>
</template>

<script>
export default {
  name: 'ProfileUpdateDone'
}
</script>

<style scoped>
@import '../assets/global.css';
</style>
