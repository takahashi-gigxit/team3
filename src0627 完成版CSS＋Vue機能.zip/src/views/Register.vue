<template>
  <p class="back-link">
   
    </p>

  <div class="login-container">
    
    <h2 class="title">新規登録</h2>

    <form @submit.prevent="handleRegister">
      <input v-model="username" type="text" placeholder="名前" class="input-box" />
      <input v-model="email" type="email" placeholder="メールアドレス" class="input-box" />
      <input v-model="password" type="password" placeholder="パスワード" class="input-box" />
      <p v-if="errorMessage" class="error-message">{{ errorMessage }}</p>
      <button type="submit" class="login-button">登録</button>
    </form>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { useRouter } from 'vue-router'
import axios from 'axios'

const username = ref('')
const email = ref('')
const password = ref('')
const errorMessage = ref('')

const router = useRouter()

const handleRegister = () => {
  if (username.value && email.value && password.value) {
    // 一時的に入力情報をローカルストレージに保存
    const userDraft = {
      username: username.value,
      email: email.value,
      password: password.value
    }
    localStorage.setItem('userDraft', JSON.stringify(userDraft))

    // 確認画面へ遷移
    router.push('/register/confirm')
  } else {
    errorMessage.value = 'すべての項目を入力してください'
  }
}

</script>

<style scoped>
@import '../assets/global.css';
</style>
