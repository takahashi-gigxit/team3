<template>
  <div style="text-align:center; margin-top:100px;">
    <h2>ダッシュボード</h2>
    <p>ログイン成功！</p>
  </div>
</template>

<script>
export default {
  name: 'Dashboard'
}
</script>
<style scoped>
@import '../assets/global.css';
</style>
