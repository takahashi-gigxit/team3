<template>
  <div class="attendance-page">
    <div class="application-box">
      <h2>申請一覧（ユーザーID: {{ userId }}）</h2>
      <h3><div v-if="applications.length === 0">申請がありません。</div></h3>

      <div class="filters">
        <!-- 申請内容 -->
        <label>
          申請内容：
          <select v-model="selectedFilter">
            <option value="全て">全て</option>
            <option v-for="type in filterTypes" :key="type" :value="type">{{ type }}</option>
          </select>
        </label>

        <!-- 月 -->
        <label>
          申請月：
          <select v-model="selectedMonth">
            <option value="全て">全て</option>
            <option v-for="m in 12" :key="m" :value="String(m).padStart(2, '0')">{{ m }}月</option>
          </select>
        </label>
      </div>

      <ul class="no-bullet">
        <li
          v-for="app in filteredApplications"
          :key="app.requestId"
          @click="goToAttendance(app.date)"
          class="application-item"
        >
          <p>申請内容：{{ app.content }}</p>
          <p>申請日：{{ app.date }}</p>
          <p>状態：{{ app.status }}</p>
          <p>理由：{{ app.reason }}</p>
        </li>
      </ul>
    </div>
  </div>
</template>

<script>
export default {
  name: 'UserAppList',
  data() {
    return {
      userId: null,
      applications: [],
      selectedFilter: '全て',
      selectedMonth: '全て',
      filterTypes: ['有給', '欠勤', '遅刻', '早退'],
    }
  },
  mounted() {
    const userStr = localStorage.getItem('user')
    if (userStr) {
      try {
        const user = JSON.parse(userStr)
        this.userId = user.id
        this.fetchApplications()
        if (user.category_id === 1) {
    this.backRoute = '/admin';
  } else if (user.category_id === 0) {
    this.backRoute = '/main';
  } else {
    this.backRoute = '/'; // 不正なcategory_idのときなど
  }

  console.log("backroute")
  console.log(this.backRoute)

      } catch (err) {
        console.error('ユーザー情報の解析に失敗しました:', err)
      }
    } else {
      console.warn('ユーザー情報が見つかりません')
    }
  },
  computed: {
  filteredApplications() {
    return this.applications.filter(app => {
      const contentMatch =
        this.selectedFilter === '全て' || app.content.includes(this.selectedFilter);

      const monthMatch =
        this.selectedMonth === '全て' ||
        (app.date && app.date.slice(5, 7) === this.selectedMonth); // dateが"2025-03-15" → "03"

      return contentMatch && monthMatch;
    });
  }
},

  methods: {
    fetchApplications() {
      if (!this.userId) return
      fetch(`http://localhost:8080/user/request/user/details/${this.userId}`)
        .then(res => {
          if (!res.ok) throw new Error(`HTTP error! status: ${res.status}`)
          return res.json()
        })
        .then(data => {
          // APIから既に必要なデータが整形されているので、そのまま格納
          this.applications = data
        
        })
        .catch(err => {
          console.error('申請一覧取得エラー:', err)
        })
    },
    goToAttendance(date) {
      this.$router.push({ name: 'AttendanceWithDate', params: { date } })
    }
  }
}
</script>

<style scoped>

h2 {
  text-align: center;
  font-size: 24px;
  color: #007acc;
  margin-bottom: 20px;
}

h3 {
  text-align: center;
  font-size: 18px;
  color: #007acc;
  margin-bottom: 20px;
}


.filters {
  display: flex;
  justify-content: center;
  gap: 40px;
  margin-bottom: 30px;
  font-size: 16px;
}

.filters label {
  display: flex;
  flex-direction: column;
  align-items: center;
  font-weight: bold;
  color: #007acc;
}

/* Select  */
.filters select {
  padding: 8px 14px;
  border: 1px solid #007acc;
  border-radius: 6px;
  background-color: #fff;
  font-size: 16px;
  font-family: inherit;
  color: #333;
  transition: border-color 0.2s ease, box-shadow 0.2s ease;
}

.filters select:focus {
  outline: none;
  box-shadow: 0 0 6px rgba(0, 123, 255, 0.4);
  border-color: #007acc;
}

.application-box {
  background-color: rgba(255, 255, 255, 0.432); /* 半透明白 */
  padding: 30px;
  border-radius: 12px;
  max-width: 800px;
  margin: 0 auto;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
}

/* 列表点击区域样式 */
.application-item {
  cursor: pointer;
  padding: 12px;
  border-bottom: 1px solid #cccccc00;
  transition: background-color 0.3s ease;
}

.application-item:hover {
  background-color: #f0f8ff4e;
}


</style>