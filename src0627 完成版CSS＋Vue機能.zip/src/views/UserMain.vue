<template>
  <div class="main-container">
    <h2 class="main-title">勤怠・工数管理</h2>
    <h3 class="main-subtitle">ようこそ、{{ username }}さん！</h3>

    <div class="summary-box" v-if="username">
      <p>本日は {{ today }} です。</p>
    </div>

    <Calendar @select-date="goToAttendance" />

  </div>
  
</template>
     
<script>
import Calendar from './Calendar.vue'

export default {
  name: 'UserMain',
  components: { Calendar },
  data() {
    return {
      username: '',
      today: new Date().toLocaleDateString('ja-JP')
    }
    
  },
  mounted() {
    const userStr = localStorage.getItem('user');
    const user = JSON.parse(userStr);
    this.username = user.username;
    console.log(user);
  },
  methods: {
    goToAttendance(dateStr) {
      this.$router.push({ path: '/attendance', query: { date: dateStr } })
    }
  }
}
</script>

<style scoped>
@import '../assets/global.css'; 
</style>
