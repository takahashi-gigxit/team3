<template>
  <div class="container">
    
    <h2>ユーザー一覧</h2>
    <div>
      <v-text-field type="text" v-model="keyword" label="検索"></v-text-field>
    </div>

    <table>
      <thead>
        <tr>
          <th>Id</th>
          <th>Name</th>
          <th>Pass</th>
          <th>Email</th>
          <th>admin</th>
          <th>編集</th>
          <th>削除</th>
        </tr>
      </thead>
      <tbody>
        <tr v-if="users.length === 0">
          <td colspan="7">現在ユーザーはいません</td>
        </tr>
        <tr v-else v-for="user in filtered" :key="user.id">
          <td>{{ user.id }}</td>
          <td>{{ user.username }}</td>
          <td>{{ user.password }}</td>
          <td>{{ user.email }}</td>
          <td><input type="checkbox" :checked="user.category_id === 1" disabled /></td>
          <td><button><router-link :to="'/user/edit/' + user.id">編集</router-link></button></td>
          <td><button @click="confirmDelete(user.id)">削除</button></td>
        </tr>
      </tbody>
    </table>
  </div>
</template>

<script setup>
import { ref,computed, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import axios from 'axios'

const users = ref([])
const showDialog = ref(false)
const userIdToDelete = ref(null)
const router = useRouter()
const keyword = ref('')

const getData = async () => {
  try {
    const res = await axios.get('http://localhost:8080/user/list')
    users.value = res.data
  } catch (error) {
    console.error(error)
  }
}

const confirmDelete = (id) => {
  const confirmed = window.confirm("本当に削除しますか？");
  if (confirmed) {
    userIdToDelete.value = id;
    deleteUser();
  }
}

const deleteUser = async () => {
  try {
    const url = `http://localhost:8080/user/delete/${userIdToDelete.value}`
    await axios.delete(url)
    showDialog.value = false
    getData()
  } catch (error) {
    console.error("削除中にエラーが発生しました(削除するユーザーが申請を出している可能性があります):", error)
    if (error.response) {
      console.error("エラーレスポンスデータ:", error.response.data)
      console.error("エラーレスポンスステータス:", error.response.status)
    }
  }
}

const cancelDialog = () => {
  showDialog.value = false
}

const editUser = (id) => {
  router.push(`/user/edit/${id}`)
}

const lowerKeywords = computed(() => {
  return keyword.value.trim().toLowerCase().split(/\s+/).filter(k => k !== "");
});

const filtered = computed(() => {
  // キーワードが空なら全件表示！
  if (lowerKeywords.value.length === 0) {
    return users.value;
  }
   // キーワードがあるときは絞り込みAdd commentMore actions
  return users.value.filter(user => {
    const name = user.username.toLowerCase();
    const email = user.email.toLowerCase();
    return lowerKeywords.value.every(kw =>
      name.includes(kw) || email.includes(kw)
    );
  });
});

onMounted(getData)
</script>



<style scoped>
@import '../assets/global.css'; 
</style>
