<template>
  <div class="calendar-container">
    <!-- 固定リンク -->
    <div class="top-right-button">
      <router-link :to="{ name: 'UserAppList', params: { userId: user_id } }" class="link-button">
      申請一覧へ ＞＞
      </router-link>
    </div>

    <div class="header">
      <h3></h3>
      <div class="header">
  <div class="month-center">
   
    <div class="month-control">
      <th><button @click="prevMonth">＜</button></th>

       <th><h4>{{ year }}年 {{ month + 1 }}月</h4></th>
       
      <th><button @click="nextMonth">＞</button></th>
    </div>
  </div>
</div>


    <table class="calendar">
      <thead>
        <tr>
          <th v-for="day in days" :key="day">{{ day }}</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="(week, index) in calendar" :key="index">
          <td
            v-for="date in week"
            :key="date.date"
            :class="[
              { outside: date.outside },
              { startMarked: date.marked.start },
              { endMarked: date.marked.end }
            ]"
            @click="handleDateClick(date)"
          >
            {{ date.day }}
          </td>
        </tr>
      </tbody>
    </table>

    <div class="legend">
      <div><span class="box start"></span> 出勤のみ</div>
      <div><span class="box end"></span> 退勤のみ</div>
      <div><span class="box both"></span> 出退勤済み</div>
    </div>

    <div class="total-time" style="margin-top: 20px;">
      {{ month + 1 }}月の合計勤務時間: <strong>{{ totalWorkHours }}</strong>
    </div>
  </div>
</div>
</template>

<script>
const user_id = localStorage.getItem('userId');
export default {
  name: 'Calendar',
  data() {
    const today = new Date();
    let user = {};
    const userStr = localStorage.getItem('user');
    try {
      user = userStr ? JSON.parse(userStr) : {};
    } catch (err) {
      console.error('ユーザー情報の読み取りに失敗しました', err);
    }

    return {
      days: ['日', '月', '火', '水', '木', '金', '土'],
      year: today.getFullYear(),
      month: today.getMonth(),
      username: localStorage.getItem('username') || 'ゲスト',
      user_id: user.id || null,
      markedDates: [],
      totalWorkHours: 0,
      selectedYearForRoute: null,
      selectedMonthForRoute: null,
      selectedDayForRoute: null,
      weeklyWeather: []  // 今週の天気情報を格納
    };
  },
  computed: {
    calendar() {
      const firstDay = new Date(this.year, this.month, 1);
      const startDay = firstDay.getDay();
      const daysInMonth = new Date(this.year, this.month + 1, 0).getDate();
      const prevMonthDays = new Date(this.year, this.month, 0).getDate();
      const totalCells = Math.ceil((startDay + daysInMonth) / 7) * 7;

      const result = [];
      let day = 1;
      let nextMonthDay = 1;

      for (let i = 0; i < totalCells; i++) {
        const row = Math.floor(i / 7);
        if (!result[row]) result[row] = [];

        if (i < startDay) {
          const d = prevMonthDays - startDay + i + 1;
          result[row].push({ day: d, outside: true, marked: false, date: `${this.year}-${this.month}-${d}` });
        } else if (day <= daysInMonth) {
          const dateStr = `${this.year}-${String(this.month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
          result[row].push({
            day: day,
            outside: false,
            marked: this.getMarkedState(dateStr),
            date: dateStr
          });
          day++;
        } else {
          const d = nextMonthDay++;
          result[row].push({ day: d, outside: true, marked: false, date: `${this.year}-${this.month + 2}-${d}` });
        }
      }

      return result;
    }
  },
  methods: {
    prevMonth() {
      if (this.month === 0) {
        this.month = 11;
        this.year--;
      } else {
        this.month--;
      }
      this.fetchMarkedDates();
    },
    nextMonth() {
      if (this.month === 11) {
        this.month = 0;
        this.year++;
      } else {
        this.month++;
      }
      this.fetchMarkedDates();
    },
    handleDateClick(date) {
      if (date.outside || this.markedDates.includes(date.date)) {
        alert('この日は既に打刻済みです');
        return;
      }

      const [yearStr, monthStr, dayStr] = date.date.split('-');
      this.selectedMonthForRoute = parseInt(monthStr, 10);
      this.selectedDayForRoute = parseInt(dayStr, 10);
      this.selectedYearForRoute = parseInt(yearStr, 10);

      this.$router.push({
        name: 'AttendanceWithDate',
        params: {
          date: date.date
        }
      });
    },
    fetchMarkedDates() {
      const userStr = localStorage.getItem('user');
      if (!userStr) {
        console.error('ユーザー情報が見つかりません');
        return;
      }

      const user = JSON.parse(userStr);
      const user_id = user.id;
      this.username = user.username;

      const yearMonth = `${this.year}-${String(this.month + 1).padStart(2, '0')}`;
      fetch(`http://localhost:8080/user/attendance/month/${user_id}?month=${yearMonth}`)
        .then(res => res.json())
        .then(data => {
          this.markedDates = data.map(d => ({
            date: d.date,
            start: d.start,
            end: d.end,
            start_time: d.start_time,
            end_time: d.end_time
          }));
          this.calculateTotalHours();
        })
        .catch(err => {
          console.error('🔴 打刻データ取得エラー', err);
        });
    },
    getMarkedState(dateStr) {
      const record = this.markedDates.find(d => d.date === dateStr);
      console.log(`▶️ ${dateStr}`, record);
      return record ? { start: record.start, end: record.end } : { start: false, end: false };
    },
    calculateTotalHours() {
      let totalMinutes = 0;

      this.markedDates.forEach(entry => {
        if (entry.start && entry.end && entry.start_time && entry.end_time) {
          const [sh, sm] = entry.start_time.split(':').map(Number);
          const [eh, em] = entry.end_time.split(':').map(Number);

          const start = sh * 60 + sm;
          const end = eh * 60 + em;

          if (end > start) {
            totalMinutes += end - start;
          }
        }
      });

      const hours = Math.floor(totalMinutes / 60);
      const minutes = totalMinutes % 60;
      this.totalWorkHours = `${hours}時間 ${minutes}分`;
  },
  fetchWeather() {
    const appid = 'de06313875fc54d7355f3c834958d9e5';
    const city = 'Tokyo,jp';

    const url = `https://api.openweathermap.org/data/2.5/forecast?q=${city}&units=metric&lang=ja&appid=${appid}`;

    fetch(url)
      .then(res => res.json())
      .then(obj => {
        // 日付ごとにまとめる
        const dailyMap = {};

        obj.list.forEach(item => {
          const dateKey = item.dt_txt.split(' ')[0]; // "YYYY-MM-DD"
          const temp = item.main.temp;
          const weather = item.weather[0].description;

          if (!dailyMap[dateKey]) {
            dailyMap[dateKey] = {
              temps: [],
              weatherCounts: {}
            };
          }

          dailyMap[dateKey].temps.push(temp);

          // よく出る天気を代表として採用
          const desc = weather;
          dailyMap[dateKey].weatherCounts[desc] = (dailyMap[dateKey].weatherCounts[desc] || 0) + 1;
        });

        // 最終的に配列化して上位5件取得
        this.weeklyWeather = Object.entries(dailyMap).slice(0, 5).map(([dateStr, data]) => {
          const date = new Date(dateStr);
          const weekday = date.toLocaleDateString('ja-JP', {
            month: 'numeric',
            day: 'numeric',
            weekday: 'short'
          });

          // 天気の中で一番出現頻度の高いもの
          const weather = Object.entries(data.weatherCounts).sort((a, b) => b[1] - a[1])[0][0];

          const temps = data.temps;
          const tempMin = Math.round(Math.min(...temps));
          const tempMax = Math.round(Math.max(...temps));

          return {
            date: `${weekday}`,
            weather,
            tempMin,
            tempMax
          };
        });
      })
      .catch(err => {
        console.error('天気情報の取得に失敗しました:', err);
      });
  },
},
mounted() {
  this.fetchMarkedDates();
  this.fetchWeather()
}
};
</script>

<style scoped>
@import '../assets/global.css';

.top-right-button {
  position: absolute;
  top: 140px;
  right: 20px;
  z-index: 10;
  display: flex;
  gap: 10px;

}


.link-button {
 background-color: #007acc;
  color: white;
  padding: 12px 20px;
  border-radius: 10px;
  font-size: 16px;
  transition: transform 0.2s ease, box-shadow 0.2s ease;
  text-decoration: none;
  box-shadow: 0 4px 12px rgba(0, 122, 204, 0.3);
}

.link-button:hover {
  background-color: #005fa3;
}
.month-center {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 20px;
  margin-bottom: 20px;
  flex-wrap: nowrap; 
}

.month-control button {
  margin: 0 5px;
  padding: 10px 12px;
  font-size: 16px;
  border-radius: 6px;
  background-color: #007acc;
  color: white;
  border: none;
  cursor: pointer;
  transition: 0.3s;
}

.month-control button:hover {
  background-color: #005fa3;
}

</style>


