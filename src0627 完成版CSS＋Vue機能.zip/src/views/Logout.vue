<template>
  <div class="logout-container">
    <h2>ログアウトしますか？</h2>
    <button @click="confirmLogout" class="logout-button">はい、ログアウト</button>
    <router-link to="/dashboard" class="cancel-link">キャンセル</router-link>
  </div>
</template>

<script>
export default {
  name: 'Logout',
  methods: {
    confirmLogout() {
      localStorage.removeItem('loggedIn')
      this.$router.push('/login')
    }
  }
}
</script>

<style scoped>
@import '../assets/global.css';
</style>
