<template>
  <header class="global-header">
    <div class="header-inner">
      <div class="logo-block">
        <!-- <img src="/logo.png" alt="ZAC logo" class="logo-img" /> -->
        <span class="logo-text">ZEC</span>
      </div>

      <button @click="showDialog = true" class="logout-link">ログアウト</button>
    </div>

    <div v-if="showDialog" class="dialog-overlay">
      <div class="dialog-box">
        <h2 class="dialog-title">ログアウトしますか？</h2>
        <div class="dialog-actions">
          <button class="confirm-button" @click="logout">確認</button>
          <button class="cancel-button" @click="showDialog = false">キャンセル</button>
        </div>
      </div>
    </div>
  </header>
</template>

<script>
export default {
  name: 'Header',
  data() {
    return {
      showDialog: false
    }
  },
  methods: {
    logout() {
      localStorage.removeItem('loggedIn')
      this.showDialog = false
      this.$router.push('/login')
    }
  }
}
</script>
<style scoped>
@import '../assets/global.css';
</style>
