<template>
  <div class="container">
    <h2>ユーザー編集</h2>
    <table>
      <thead>
        <tr>
          <th>Name</th>
          <th>Pass</th>
          <th>Email</th>
          <th>admin</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td><input v-model="form.username" type="text" /></td>
          <td><input v-model="form.password" type="password" /></td>
          <td><input v-model="form.email" type="email" /></td>
          <td><input type="checkbox" v-model="form.isAdmin" /></td>
        </tr>
      </tbody>
    </table>

    <!-- ✅ 改成统一样式的确认弹窗 -->
    <div v-if="showDialog" class="dialog-overlay">
      <div class="dialog-box">
        <h2 class="dialog-message">更新しますか</h2>
        <div class="actions">
          <button @click="updateUser">はい</button>
          <button @click="cancelDialog">いいえ</button>
        </div>
      </div>
    </div>

    <button @click="confirmUpdate">更新</button>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import axios from 'axios'

const route = useRoute()
const router = useRouter()
const userId = ref(null)
const form = ref({
  username: '',
  password: '',
  email: '',
  isAdmin: false
})
const showDialog = ref(false)

const getData = async () => {
  userId.value = route.params.id
  try {
    const res = await axios.get(`http://localhost:8080/master/home/${userId.value}`)
    const userData = res.data
    form.value.username = userData.username
    form.value.password = userData.password
    form.value.email = userData.email
    form.value.isAdmin = userData.category_id === 1
  } catch (error) {
    console.error('ユーザーデータの取得中にエラーが発生しました:', error)
    alert('ユーザーデータの読み込みに失敗しました。')
    router.push('/user/list')
  }
}

const confirmUpdate = () => {
  showDialog.value = true
}

const updateUser = async () => {
  try {
    const payload = {
      id: userId.value,
      username: form.value.username,
      password: form.value.password,
      email: form.value.email,
      category_id: form.value.isAdmin ? 1 : 0
    }
    await axios.put(`http://localhost:8080/user/edit/${userId.value}`, payload)
    showDialog.value = false
    alert('ユーザー情報が正常に更新されました。')
    router.push('/user/list')
  } catch (error) {
    console.error('ユーザーの更新中にエラーが発生しました:', error)
    alert('ユーザーの更新に失敗しました。')
    if (error.response) {
      console.error('エラーレスポンスデータ:', error.response.data)
      console.error('エラーレスポンスステータス:', error.response.status)
    }
  }
}

const cancelDialog = () => {
  showDialog.value = false
}

onMounted(getData)
</script>

<style scoped>
.dialog-overlay {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(229, 237, 239, 0.836);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 1000;
}

.dialog-box {
  background-color: #fff;
  padding: 30px 40px;
  border-radius: 12px;
  box-shadow: 0 8px 20px rgba(0, 0, 0, 0.2);
  max-width: 400px;
  width: 90%;
  text-align: center;
  font-family: 'Noto Sans JP', sans-serif;
}

.dialog-message {
  font-size: 20px;
  font-weight: bold;
  color: #222;
  margin-bottom: 20px;
  padding: 12px;
  border: 2px solid #007acc;
  border-radius: 8px;
  background-color: #f4faff;
  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);
}

.actions {
  display: flex;
  justify-content: space-around;
  gap: 20px;
}

.actions button {
  padding: 10px 20px;
  font-size: 14px;
  border: none;
  border-radius: 6px;
  background-color: #007acc;
  color: white;
  cursor: pointer;
  transition: all 0.2s ease;
}

.actions button:hover {
  background-color: #005fa3;
}

table input[type="text"],
table input[type="password"],
table input[type="email"] {
  width: 240px;
  padding: 6px 10px;
  font-size: 14px;
  border: 1px solid #ccc;
  border-radius: 6px;
  box-sizing: border-box;
}

table input[type="checkbox"] {
  width: auto;
}

table {
  border-collapse: collapse;
  margin: 0 auto;
}

th, td {
  text-align: center;
  padding: 12px 16px;
}

thead {
  background-color: #007acc;
  color: white;
}

button {
  margin-top: 20px;
  padding: 10px 20px;
  background-color: #007acc;
  color: white;
  border: none;
  border-radius: 6px;
  cursor: pointer;
}

button:hover {
  opacity: 0.9;
  transform: scale(1.02);
}

@import '../assets/global.css';
</style>
