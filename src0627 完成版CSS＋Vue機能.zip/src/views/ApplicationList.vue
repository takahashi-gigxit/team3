<template>
  <div class="container">
    
    <h2>申請一覧表</h2>
     <div>
      <v-text-field type="text" v-model="keyword" label="検索"></v-text-field>
    </div>
    <table>
      <thead>
        <tr>
          <th>日付</th>
          <th>名前</th>
          <th>種類</th>
          <th>理由</th>
          <th>削除</th>
        </tr>
      </thead>
      <tbody>
        <tr v-if="applications.length === 0">
          <td colspan="5">現在データはありません</td>
        </tr>
        <tr v-else v-for="item in filtered" :key="item.id">
          <td>{{ item.date }}</td>
          <td>{{ item.username }}</td>
          <td>
            {{ item.requestType }}
            </td>
            <td>{{ item.reason }}</td>
          <td><button @click="confirmDelete(item.deleteId, item.recordType)">削除</button></td>
        </tr>
      </tbody>
    </table>

    <div v-if="showDialog" class="dialog">
      <p>削除しますか</p>
      <button @click="deleteApplication">はい</button>
      <button @click="cancelDialog">いいえ</button>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import axios from 'axios';

const applications = ref([]);
const showDialog = ref(false);
const itemToDelete = ref(null);

const keyword = ref('')
const API_BASE_URL = 'http://localhost:8080';

const fetchUsers = async () => {
  try {
    const response = await axios.get(`${API_BASE_URL}/user/list`);
    return response.data;
  } catch (error) {
    console.error('ユーザーの取得中にエラーが発生しました:', error);
    return [];
  }
};

const fetchAttendances = async () => {
  try {
    const response = await axios.get(`${API_BASE_URL}/application/attendance`);
    return response.data;
  } catch (error) {
    console.error('勤怠記録の取得中にエラーが発生しました:', error);
    return [];
  }
};

const fetchRequests = async () => {
  try {
    const response = await axios.get(`${API_BASE_URL}/application/request`);
    return response.data;
  } catch (error) {
    console.error('申請記録の取得中にエラーが発生しました:', error);
    return [];
  }
};

const fetchAllApplications = async () => {
  try {
    const response = await axios.get(`${API_BASE_URL}/application/combined`);
    applications.value = response.data.sort((a, b) => new Date(a.date) - new Date(b.date));
  } catch (error) {
    console.error('結合された申請データの取得に失敗しました:', error);
    applications.value = [];
  }
};

const getApplicationType = (item) => {
  const types = [];
  if (item.paid === 1) types.push('有給');
  if (item.early === 1) types.push('早退');
  if (item.absence === 1) types.push('欠勤');
  if (item.late === 1) types.push('遅刻');
  return types.length > 0 ? types.join(', ') : '情報なし';
};

const confirmDelete = (id, type) => {
  itemToDelete.value = { id, type };
  showDialog.value = true;
};

const deleteApplication = async () => {
  if (!itemToDelete.value || !itemToDelete.value.id) {
    alert('削除対象が選択されていません。');
    return;
  }

  const { id, type } = itemToDelete.value;
  let url = '';

  try {
    if (type === 'request') {
      url = `${API_BASE_URL}/application/delete/${id}`;
      await axios.delete(url);
      alert('申請が正常に削除されました。');

      applications.value = applications.value.filter(item => !(item.recordType === 'request' && item.deleteId === id));

    } else if (type === 'attendance') {

      url = `${API_BASE_URL}/application/attendance/delete/${id}`;
      await axios.delete(url);
      alert('勤怠記録が正常に削除されました。');
      applications.value = applications.value.filter(item => !(item.recordType === 'attendance' && item.deleteId === id));

    } else {
      alert('不明なタイプのレコードです。');
    }

    fetchAllApplications();

  } catch (error) {
    console.error('削除中にエラーが発生しました:', error);
    alert('削除中にエラーが発生しました。詳細はコンソールを確認してください。');
    if (error.response) {
      console.error("エラーレスポンスデータ:", error.response.data);
      console.error("エラーレスポンスステータス:", error.response.status);
    }
  } finally {
    showDialog.value = false;
    itemToDelete.value = null;
  }
};
const cancelDialog = () => {
  showDialog.value = false;
  itemToDelete.value = null;
};
const lowerKeywords = computed(() => {
  return keyword.value.trim().toLowerCase().split(/\s+/).filter(k => k !== "");
});

const filtered = computed(() => {
  if (lowerKeywords.value.length === 0) {
    return applications.value;
  }

  return applications.value.filter(item => {
    const name = item.username?.toLowerCase() || '';
    const type = item.requestType?.toLowerCase() || '';
    const date = item.date?.toLowerCase?.() || ''; // 念のため

    return lowerKeywords.value.every(kw =>
      name.includes(kw) || type.includes(kw) || date.includes(kw)
    );
  });
});
onMounted(() => {
  fetchAllApplications();
});
</script>
<style scoped>
@import '../assets/global.css'; /* 确保引用统一样式 */
</style>

