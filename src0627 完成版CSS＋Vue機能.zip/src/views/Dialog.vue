<template>
  <div class="dialog-overlay" v-if="visible">
    <div class="dialog-box">
      <h2 class="dialog-message">{{ message }}</h2>
      <div class="actions">
        <button @click="$emit('confirm')">確認</button>
        <button @click="$emit('cancel')">キャンセル</button>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'Dialog',
  props: {
    visible: Boolean,
    message: String
  }
}
</script>

<style scoped>
.dialog-overlay {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(229, 237, 239, 0.836);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 1000;
}

.dialog-box {
  background-color: #fff;
  padding: 30px 40px;
  border-radius: 12px;
  box-shadow: 0 8px 20px rgba(0, 0, 0, 0.2);
  max-width: 400px;
  width: 90%;
  text-align: center;
  font-family: 'Noto Sans JP', sans-serif;
}

/* ✅ 唯一的、有效的 h2 样式 */
.dialog-message {
  font-size: 20px;
  font-weight: bold;
  color: #222;
  margin-bottom: 20px;
  padding: 12px;
  border: 2px solid #007acc;
  border-radius: 8px;
  background-color: #f4faff;
  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);
}

.actions {
  display: flex;
  justify-content: space-around;
  gap: 20px;
}

.actions button {
  padding: 10px 20px;
  font-size: 14px;
  border: none;
  border-radius: 6px;
  background-color: #007acc;
  color: white;
  cursor: pointer;
  transition: all 0.2s ease;
}

.actions button:hover {
  background-color: #005fa3;
}

</style>
