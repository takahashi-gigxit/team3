<template>
  <div class="main-container">
    <h2 class="main-title">勤怠・工数管理</h2>
    <h3 class="main-subtitle">ようこそ（総務）さん</h3>

    <Calendar @select-date="goToAttendance" />

  </div>
  <div class="top-right-buttons">
  <router-link to="/admin/approval" class="link-button">申請承認へ＞＞</router-link>
  </div>
</template>

<script>
import Calendar from './Calendar.vue'

export default {
 name: 'UserMain',
  components: { Calendar },
   data() {
    return {
      username: '', // 将来：ログインユーザー名を取得
      today: new Date().toLocaleDateString('ja-JP')
    }
  },
  methods: {
    goToAttendance(dateStr) {
      this.$router.push({ path: '/attendance', query: { date: dateStr } })
    }
  },
  mounted() {
    const userStr = localStorage.getItem('user');
    const user = JSON.parse(userStr);
    this.username = user.username;
    console.log(user);
  }
}

</script>

<style scoped>
@import '../assets/global.css'; /* 确保引用统一样式 */
</style>
