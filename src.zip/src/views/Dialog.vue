<template>
  <div class="dialog-overlay" v-if="visible">
    <div class="dialog-box">
      <p>{{ message }}</p>
      <div class="actions">
        <button @click="$emit('confirm')">確認</button>
        <button @click="$emit('cancel')">キャンセル</button>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'Dialog',
  props: {
    visible: Boolean,
    message: String
  }
}
</script>

<style scoped>
@import '../assets/global.css';
</style>
