<script setup>
import { ref } from 'vue'
import axios from 'axios'
import { useRouter } from 'vue-router'

const props = defineProps({
  type: {
    type: String,
    default: 'user'
  }
})

const router = useRouter()
const email = ref('')
const password = ref('')
const errorMessage = ref('')

const login = async () => {
  try {
    const response = await axios.post('http://localhost:8080/login', {
      email: email.value,
      password: password.value,
    }, {
      headers: {
        'Content-Type': 'application/json'
      }
    })

    console.log('ログイン成功', response.data)
    localStorage.setItem('user', JSON.stringify(response.data))

    const categoryId = response.data.category_id
    console.log("categoryId");
    console.log(categoryId);
    if (categoryId === 2) {
      router.push('/master/home')
      console.log("categoryadmin");
    } else if (categoryId === 1 ) {
      router.push(`/admin`)
    } else if( categoryId === 0){
      router.push(`/main`)
    }
    else {
      alert('不正な権限です')
    }

  } catch (error) {
    console.error('ログイン失敗', error)
    errorMessage.value = 'ログインに失敗しました。メールアドレスとパスワードを確認してください。'
  }
}
</script>


<template>
  <div class="login-container">
    <h2 class="title">ログイン</h2>
    <div class="form">
      <input class="input-box" v-model="email" type="email" placeholder="メールアドレス" />
      <input class="input-box" v-model="password" type="password" placeholder="パスワード" />
      <button @click="login">ログイン</button>
    </div>
    <p class="register-link">
      <router-link to="/register">新規登録はこちら</router-link>
    </p>
  </div>
</template>



<style scoped>
@import '../assets/global.css';
</style>