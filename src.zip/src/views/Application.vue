<template>
  <div class="application-page">
    <!-- ヘッダー -->
    <div class="header">
       <h2 class="title">申請</h2>
       <p class="date">{{ displaydate }}</p>Add commentMore actions
       <p>有給残日数：{{ paidDate }} 日</p> <!-- ★ 追加表示 -->
    </div>

   
   

    <!-- 申請ボタン -->
    <div class="button-grid">
      <div class="button-row" v-for="type in types" :key="type.key">
        <button class="app-btn" @click="confirmApply(type.key)" :disabled="request[type.key] === 1 || (type.key === 'paid' && paidDate <= 0) ">Add commentMore actions
          {{ type.label }}申請Add commentMore actions
        </button>
         <button v-if="request[type.key] === 1" class="cancel-btn" @click="confirmCancel(type.key)">取消Add commentMore actions
        </button>
      </div>
    </div>
   <!-- 理由入力ダイアログ -->Add commentMore actions
    <div v-if="showReasonDialog" class="dialog-overlay">
      <div class="dialog-box">
        <h3 class="dialog-title">{{ currentTypeJapanese }}の理由を入力してください</h3>
        <textarea v-model="reason" rows="4" style="width: 100%; resize: none;"></textarea>
        <div class="dialog-actions" style="margin-top: 12px;">
          <button class="confirm-button" @click="proceedToConfirmation">次へ</button>
          <button class="cancel-button" @click="cancelReasonInput">キャンセル</button>Add commentMore actions
        </div>
      </div>
    </div>

    <!-- ダイアログ -->
    <div v-if="showDialog" class="dialog-overlay">
      <div class="dialog-box">
        <h3 class="dialog-title">{{ currentType }}申請をしますか？</h3>
        <div class="dialog-actions">
          <button class="confirm-button" @click="submitApplication">はい</button>
          <button class="cancel-button" @click="showDialog = false">いいえ</button>
        </div>
      </div>
    </div>

    <div v-if="showCancelDialog" class="dialog-overlay">
      <div class="dialog-box">
        <h3 class="dialog-title">{{ cancelTypeJapanese }}申請を取り消しますか？</h3>
        <div class="dialog-actions">
          <button class="confirm-button" @click="submitCancel">はい</button>
          <button class="cancel-button" @click="showCancelDialog = false">いいえ</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import axios from 'axios';
export default {
  name: 'Application',
  props: ['requestId'],
  data() {
    const today = new Date()
    return {
      Requestid: this.$route.params.requestId,
      displaydate: '',
      selectdate: '',
      showDialog: false,
      showReasonDialog: false,
      currentType: '',
      showCancelDialog: false,
      cancelType: '',
      request: {},
      paidDate:0,
      types: [
        { key: 'late', label: '遅刻' },
        { key: 'early', label: '早退' },
        { key: 'absence', label: '欠勤' },
        { key: 'paid', label: '有給' }
      ],
    }
  },
  computed: {
    currentTypeJapanese() {
      return {
        late: '遅刻',
        early: '早退',
        absence: '欠勤',
        paid: '有給'
      }[this.currentType] || '';
    },
    cancelTypeJapanese() {
      return {
        late: '遅刻',
        early: '早退',
        absence: '欠勤',
        paid: '有給'
      }[this.cancelType] || '';
    }
  },
  created() {
    this.fetchRequest();
  },
  methods: {
    fetchRequest() {
      axios.get(`http://localhost:8080/user/request/${this.Requestid}`)
        .then(res => {
          this.request = res.data;
          this.fetchPaidDate(this.request.userid);

          axios.get(`http://localhost:8080/user/attendance/${this.Requestid}`)
            .then(res => {
              let year, month, day;
              [year, month, day] = res.data.date.split('-')
              this.displaydate = `${year}年${month}月${day}日`;
              this.selectdate = res.data.date;
            })
            
        })
        .catch(err => {
          console.error('Request取得エラー', err);
        });
    },
    fetchPaidDate(userId){
      // 修正：ユーザーIDを使って専用エンドポイントを呼ぶ
      axios.get(`http://localhost:8080/user/user/${userId}/paidDate`)
        .then(res => {
          this.paidDate = res.data.paidDate || 0;
        })
        .catch(err => {
          console.error('有給残日数取得エラー', err);
          this.paidDate = 0;
        });
    },
    confirmApply(type) {
      this.currentType = type
      this.showDialog = true
      this.reason = '' // 初期化（念のため）Add commentMore actions
      this.showReasonDialog = true // まずは理由入力のダイアログを出す
    },
    confirmCancel(type) {
      this.cancelType = type;
      this.showCancelDialog = true;
    },
     proceedToConfirmation() {
      if (!this.reason.trim()) {
        alert("理由を入力してください");
        return;
      }
      this.showReasonDialog = false;
      this.showDialog = true;
    },
    cancelReasonInput() {
      this.reason = '';
      this.currentType = '';
      this.showReasonDialog = false;
    },
    
    
    submitApplication() {
      const updatedRequest = {
        ...this.request,//requestのコピーを作成
        late: 0,
        early: 0,
        absence: 0,
        paid: 0,
        late_app: 0,
        early_app: 0,
        absence_app: 0,
        paid_app: 0,
      };

      // 押されたボタンの種類のみ 1 をセット
      updatedRequest[this.currentType] = 1;

       axios.put(`http://localhost:8080/user/request/${this.Requestid}`, updatedRequest)
        .then(() => {
          alert(`${this.currentTypeJapanese}申請を送信しました。`);
          this.showDialog = false;
          this.reason = '';
          this.currentType = '';
          this.fetchRequest();
        })
        .catch(err => {
          alert('申請に失敗しました');
          console.error(err);
          this.showDialog = false;
        });

      // fetch('http://localhost:8080/api/application', {
      //   method: 'POST',
      //   headers: { 'Content-Type': 'application/json' },
      //   body: JSON.stringify({
      //     userId: 1,
      //     type: this.currentType,
      //     date: new Date().toISOString().split('T')[0]
      //   })
      // })
      //   .then(res => res.json())
      //   .then(() => {
      //     alert(`${this.currentType}申請を送信しました。`)
      //     this.showDialog = false
      //   })
      //   .catch(err => {
      //     alert('申請に失敗しました')
      //     console.error(err)
      //     this.showDialog = false
      //   })
    },
    submitCancel() {
      const updatedRequest = {
        ...this.request,
        late: 0,
        early: 0,
        absence: 0,
        paid: 0,
        late_app: 0,
        early_app: 0,
        absence_app: 0,
        paid_app: 0,
        reason: '',
      };
      updatedRequest[this.cancelType] = 0;

      axios.put(`http://localhost:8080/user/request/${this.Requestid}`, updatedRequest)
        .then(() => {
          alert(`${this.cancelTypeJapanese}申請を取り消しました。`);
          this.showCancelDialog = false;
          this.fetchRequest();
        })
        .catch(err => {
          alert('取り消しに失敗しました');
          console.error(err);
          this.showCancelDialog = false;
        });
    }
  }
}
</script>

<style scoped>
@import '../assets/global.css'; /* 确保引用统一样式 */
</style>
