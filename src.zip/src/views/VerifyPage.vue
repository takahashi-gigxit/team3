<template>
  <div class="confirm-container">
    <h2 class="title">認証コードを入力</h2>
    
    <input class="input-box" v-model="code" placeholder="認証コード" />
    <button @click="verify">認証</button>
    
    <p v-if="error" style="color: red;">{{ error }}</p>
  </div>
</template>

<script>
export default {
  data() {
    return {
      code: '',
      error: '',
      email: this.$route.query.email // 前の画面からメールアドレスを引き継ぐ
    }
  },
  methods: {
    async verify() {
      this.error = ''
      try {
        const response = await fetch('http://localhost:8080/api/auth/verify', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ email: this.email, code: this.code })
        })

        if (!response.ok) {
          throw new Error('認証失敗')
        }
        alert('ログイン成功')
        this.$router.push({ name: 'Login' }) 
      } catch (err) {
        this.error = '認証に失敗しました'
      }
    }
  }
}
</script>

<style scoped>
@import '../assets/global.css';
</style>
