<template>
  <div class="confirm-container">
    

    <h2 class="title">登録確認</h2>

    <div class="info-box">
      <p>名前 : {{ userDraft.username }}</p>
      <p>メールアドレス : {{ userDraft.email }}</p>
      <p>パスワード : {{ userDraft.password }}</p>
    </div>

    <p class="confirm-text">以上の内容で登録しますか？</p>

    <button @click="registerUser" class="confirm-button">完了</button>

    <div v-if="showDialog" class="dialog-overlay">
      <div class="dialog-box">
        <p class="dialog-title">登録完了しました！</p>
        <button @click="goToVerify" class="ok-button">確認</button>
      </div>
    </div>
  </div>
</template>

<script>
import axios from 'axios'

export default {
  data() {
    return {
      showDialog: false,
      userDraft: {
        username: '',
        email: '',
        password: ''
      }
    }
  },
  mounted() {
    const stored = localStorage.getItem('userDraft')
    if (stored) {
      this.userDraft = JSON.parse(stored)
    } else {
      alert('不正なアクセスです')
      this.$router.push('/register')
    }
  },
  methods: {
    async registerUser() {
      try {
        // ユーザーを登録
        await axios.post('http://localhost:8080/register', this.userDraft, {
          headers: { 'Content-Type': 'application/json' }
        })

        // 認証コードを送信
        await axios.post('http://localhost:8080/api/auth/send-code', {
          email: this.userDraft.email
        }, {
          headers: { 'Content-Type': 'application/json' }
        })

        this.showDialog = true
        localStorage.removeItem('userDraft')
      } catch (e) {
        alert('登録またはメール送信に失敗しました')
        console.error(e)
      }
    },
    goToVerify() {
      // EmailVerify に遷移（メールアドレスをクエリで渡す）
      this.$router.push({ name: 'EmailVerify', query: { email: this.userDraft.email } })
    }
  }
}
</script>
<style scoped>
@import '../assets/global.css';
</style>
